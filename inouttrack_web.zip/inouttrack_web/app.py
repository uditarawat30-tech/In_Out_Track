# app.py
from flask import Flask, render_template, request, redirect, url_for, session, flash
import os, json, hashlib
from datetime import datetime

APP_DIR = os.path.dirname(os.path.abspath(__file__))
DATA_FILE = os.path.join(APP_DIR, "inouttrack_data.json")

app = Flask(__name__)
app.secret_key = "replace_this_with_a_random_secret_for_prod"  # for session

# -----------------------
# Simple JSON datastore
# -----------------------
def init_store():
    if not os.path.exists(DATA_FILE):
        base = {
            "users": [],        # wardens (username, password_hash)
            "students": [],     # {student_id, name}
            "attendance": [],   # {id, student_id, action, timestamp}
            "leaves": [],       # {id, student_id, from_date, to_date, reason, status}
            "next_ids": {"attendance": 1, "leave": 1, "student": 100}
        }
        with open(DATA_FILE, "w") as f:
            json.dump(base, f, indent=2)

def read_store():
    init_store()
    with open(DATA_FILE, "r") as f:
        return json.load(f)

def write_store(data):
    with open(DATA_FILE, "w") as f:
        json.dump(data, f, indent=2)

# -----------------------
# Helpers (auth + CRUD)
# -----------------------
def hash_password(pw):
    return hashlib.sha256(pw.encode()).hexdigest()

def find_user(username):
    data = read_store()
    for u in data["users"]:
        if u["username"] == username:
            return u
    return None

def add_warden(username, password):
    if find_user(username):
        raise ValueError("Username exists")
    rec = {"username": username, "password_hash": hash_password(password)}
    data = read_store()
    data["users"].append(rec)
    write_store(data)

def add_student(name):
    data = read_store()
    sid = data["next_ids"]["student"]
    data["next_ids"]["student"] += 1
    rec = {"student_id": sid, "name": name}
    data["students"].append(rec)
    write_store(data)
    return sid

def get_students():
    return read_store()["students"]

def add_attendance(student_id, action):
    data = read_store()
    rec = {
        "id": data["next_ids"]["attendance"],
        "student_id": student_id,
        "action": action,
        "timestamp": datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    }
    data["next_ids"]["attendance"] += 1
    data["attendance"].append(rec)
    write_store(data)

def get_attendance_by_student(student_id):
    data = read_store()
    return [r for r in data["attendance"] if r["student_id"] == student_id]

def get_all_attendance():
    return read_store()["attendance"]

def add_leave(student_id, from_date, to_date, reason):
    data = read_store()
    rec = {
        "id": data["next_ids"]["leave"],
        "student_id": student_id,
        "from_date": from_date,
        "to_date": to_date,
        "reason": reason,
        "status": "pending"
    }
    data["next_ids"]["leave"] += 1
    data["leaves"].append(rec)
    write_store(data)
    return rec["id"]

def get_leaves_by_student(student_id):
    data = read_store()
    return [r for r in data["leaves"] if r["student_id"] == student_id]

def get_all_leaves():
    return read_store()["leaves"]

def update_leave_status(leave_id, status):
    data = read_store()
    for r in data["leaves"]:
        if r["id"] == leave_id:
            r["status"] = status
            write_store(data)
            return True
    return False

# -----------------------
# Routes
# -----------------------
@app.route("/")
def index():
    return redirect(url_for("login"))

# Signup (create warden) - allowed if no warden exists or user chooses to create
@app.route("/signup", methods=["GET", "POST"])
def signup():
    if request.method == "POST":
        username = request.form.get("username", "").strip()
        password = request.form.get("password", "").strip()
        if not username or not password:
            flash("Enter username & password")
            return redirect(url_for("signup"))
        try:
            add_warden(username, password)
            flash("Warden account created. Please login.")
            return redirect(url_for("login"))
        except Exception as e:
            flash(str(e))
            return redirect(url_for("signup"))
    return render_template("signup.html")

@app.route("/login", methods=["GET", "POST"])
def login():
    if request.method == "POST":
        username = request.form.get("username", "").strip()
        password = request.form.get("password", "").strip()
        user = find_user(username)
        if user and user["password_hash"] == hash_password(password):
            session["warden"] = username
            return redirect(url_for("dashboard"))
        else:
            flash("Invalid credentials")
            return redirect(url_for("login"))
    return render_template("login.html")

@app.route("/logout")
def logout():
    session.pop("warden", None)
    flash("Logged out")
    return redirect(url_for("login"))

def ensure_login():
    return "warden" in session

@app.route("/dashboard")
def dashboard():
    if not ensure_login():
        return redirect(url_for("login"))
    students = get_students()
    return render_template("dashboard.html", warden=session.get("warden"), students=students)

# Add student
@app.route("/add_student", methods=["GET", "POST"])
def route_add_student():
    if not ensure_login():
        return redirect(url_for("login"))
    if request.method == "POST":
        name = request.form.get("name", "").strip()
        if not name:
            flash("Enter name")
            return redirect(url_for("route_add_student"))
        sid = add_student(name)
        flash(f"Student added with ID {sid}")
        return redirect(url_for("dashboard"))
    return render_template("add_student.html")

# Mark Attendance
@app.route("/mark_attendance", methods=["GET", "POST"])
def route_mark_attendance():
    if not ensure_login():
        return redirect(url_for("login"))
    students = get_students()
    if request.method == "POST":
        sid = int(request.form.get("student_id"))
        action = request.form.get("action")
        if action not in ("in", "out"):
            flash("Invalid action")
            return redirect(url_for("route_mark_attendance"))
        add_attendance(sid, action)
        flash("Attendance recorded")
        return redirect(url_for("dashboard"))
    return render_template("mark_attendance.html", students=students)

# Apply leave
@app.route("/apply_leave", methods=["GET", "POST"])
def route_apply_leave():
    if not ensure_login():
        return redirect(url_for("login"))
    students = get_students()
    if request.method == "POST":
        sid = int(request.form.get("student_id"))
        fd = request.form.get("from_date")
        td = request.form.get("to_date")
        reason = request.form.get("reason", "")
        # basic validation
        try:
            # naive date check
            datetime.strptime(fd, "%Y-%m-%d")
            datetime.strptime(td, "%Y-%m-%d")
        except:
            flash("Dates must be YYYY-MM-DD")
            return redirect(url_for("route_apply_leave"))
        add_leave(sid, fd, td, reason)
        flash("Leave applied (pending)")
        return redirect(url_for("dashboard"))
    return render_template("apply_leave.html", students=students)

# View students
@app.route("/view_students")
def view_students():
    if not ensure_login():
        return redirect(url_for("login"))
    return render_template("view_students.html", students=get_students())

# View attendance of a student
@app.route("/view_attendance")
def view_attendance_page():
    if not ensure_login():
        return redirect(url_for("login"))
    sid = request.args.get("student_id", type=int)
    records = []
    if sid:
        records = get_attendance_by_student(sid)
    return render_template("view_attendance.html", students=get_students(), records=records, selected=sid)

# View all leaves
@app.route("/view_leaves")
def view_leaves_page():
    if not ensure_login():
        return redirect(url_for("login"))
    sid = request.args.get("student_id", type=int)
    if sid:
        rows = get_leaves_by_student(sid)
    else:
        rows = get_all_leaves()
    return render_template("view_leaves.html", students=get_students(), rows=rows, selected=sid)

# Update leave status
@app.route("/update_leave", methods=["POST"])
def update_leave():
    if not ensure_login():
        return redirect(url_for("login"))
    lid = int(request.form.get("leave_id"))
    status = request.form.get("status")
    if status not in ("approved", "rejected", "pending"):
        flash("Invalid status")
    else:
        ok = update_leave_status(lid, status)
        if not ok:
            flash("Leave id not found")
        else:
            flash("Updated leave status")
    return redirect(url_for("view_leaves_page"))

# All attendance (JSON view)
@app.route("/all_attendance")
def all_attendance():
    if not ensure_login():
        return redirect(url_for("login"))
    return {"attendance": get_all_attendance()}

# -----------------------
# Run app
# -----------------------
if __name__ == "__main__":
    init_store()
    app.run(debug=True)
