// script.js : empty for now (you can add small interactivity)
console.log("InOutTrack frontend loaded");
