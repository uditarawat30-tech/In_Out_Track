OPEN TERMINAL>>> PASTE THIS

venv\Scripts\activate.bat




python app.py




(OPEN ON BROWSER)>>>>
http://127.0.0.1:5000/
